<?php
define('IS_AJAX', true);
session_set_cookie_params(172800);
session_start();
require('../core/config.php');
require('../core/auth.php');
require('../core/system.php');

$system = new System;
$system->domain = $domain;
$system->db = $db;

$id = $_GET['notification_id'];

$db->query("UPDATE notifications SET is_screen='1' WHERE id='".$id."'");